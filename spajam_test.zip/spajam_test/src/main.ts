import { AMDF } from 'pitchfinder';

// 12平均律の音名（ドレミ）リスト
const notesListJP = ['ド', 'ド♯', 'レ', 'レ♯', 'ミ', 'ファ', 'ファ♯', 'ソ', 'ソ♯', 'ラ', 'ラ♯', 'シ'];

// UI要素の取得
const startButton = document.getElementById('startButton') as HTMLButtonElement;
const noteDisplay = document.getElementById('noteDisplay') as HTMLDivElement;
const frequencyDisplay = document.getElementById('frequencyDisplay') as HTMLSpanElement;

// Web Audio API と 解析用の変数
let audioContext: AudioContext | null = null;
let analyser: AnalyserNode | null = null;
let detectPitch: ((float32Array: Float32Array) => number | null) | null = null;
let audioData: Float32Array;

// 周波数をドレミ（音名とオクターブ）に変換する関数
function frequencyToNoteJP(frequency: number): string {
  // A4(440Hz)を基準にMIDIノート番号を計算
  const noteNum = 12 * Math.log2(frequency / 440) + 69;
  const noteNumRounded = Math.round(noteNum);
  
  const noteIndex = noteNumRounded % 12;
  const octave = Math.floor(noteNumRounded / 12) - 1;
  
  return `${notesListJP[noteIndex]}${octave}`;
}

// ピッチ検出と描画のメインループ
function updatePitch() {
  if (!analyser || !detectPitch) return;

  // 現在の音声波形データをFloat32Arrayに書き込む
  analyser.getFloatTimeDomainData(audioData);
  
  // pitchfinderで周波数を計算
  const frequency = detectPitch(audioData);

  // 極端なノイズ（50Hz以下、2000Hz以上など）を除外して表示
  if (frequency && frequency > 50 && frequency < 2000) {
    const note = frequencyToNoteJP(frequency);
    noteDisplay.innerText = note;
    frequencyDisplay.innerText = frequency.toFixed(1);
  }

  // ブラウザの描画タイミングに合わせてループを実行
  requestAnimationFrame(updatePitch);
}

// アプリの起動（マイクの許可と初期化）
async function startApp() {
  try {
    audioContext = new AudioContext();
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    
    // アナライザー（波形取得器）の設定
    analyser = audioContext.createAnalyser();
    analyser.fftSize = 2048; // 取得する配列のサイズ
    audioData = new Float32Array(analyser.fftSize);

    // マイクのストリームをアナライザーに接続
    const source = audioContext.createMediaStreamSource(stream);
    source.connect(analyser);

    // ピッチ検出器の初期化（マイクのサンプリングレートに合わせる）
    detectPitch = AMDF({ sampleRate: audioContext.sampleRate });

    // 認識ループを開始
    updatePitch();
    
    // UIの更新
    startButton.disabled = true;
    startButton.innerText = '音声認識中...';
    
  } catch (error) {
    console.error('マイクアクセスエラー:', error);
    noteDisplay.innerText = 'エラー';
  }
}

// ボタンにクリックイベントを紐付け
startButton.addEventListener('click', startApp);